import curso_dao
from flask import Blueprint, render_template


admin_bp = Blueprint(
    'admin',
    __name__,
    template_folder='templates',
    static_folder='static',
    static_url_path='/static/admin/'
)


@admin_bp.route('/')
def home():
    return render_template('home.html')


@admin_bp.route('/cursos/')
def cursos_lista():
    cursos = curso_dao.listar_todos_cursos()
    return render_template(
        'cursos_lista.html',
        cursos=cursos
    )


@admin_bp.route('/cursos/novo/')
def curso_novo():
    erros = {}
    
    return render_template(
        'cursos_form.html',
        erros=erros
    )
